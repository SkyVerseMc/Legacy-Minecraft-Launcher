package net.minecraft.hopper;

public class Crash {
  private int id;
  
  private String jira_issue;
  
  private String title;
  
  public int getId() {
    return this.id;
  }
  
  public String getJira_issue() {
    return this.jira_issue;
  }
  
  public String getTitle() {
    return this.title;
  }
}


/* Location:              C:\Users\Admin\dev\LegacyLauncher\launcher\minecraft.jar!\net\minecraft\hopper\Crash.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */