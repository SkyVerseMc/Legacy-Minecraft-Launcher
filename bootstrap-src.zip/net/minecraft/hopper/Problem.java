package net.minecraft.hopper;

public class Problem {
  private String title;
  
  private String description;
  
  private String url;
  
  public String getTitle() {
    return this.title;
  }
  
  public String getDescription() {
    return this.description;
  }
  
  public String getUrl() {
    return this.url;
  }
}


/* Location:              C:\Users\Admin\dev\LegacyLauncher\launcher\minecraft.jar!\net\minecraft\hopper\Problem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */