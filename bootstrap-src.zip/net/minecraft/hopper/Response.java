package net.minecraft.hopper;

public class Response {
  private String error;
  
  public String getError() {
    return this.error;
  }
}


/* Location:              C:\Users\Admin\dev\LegacyLauncher\launcher\minecraft.jar!\net\minecraft\hopper\Response.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */