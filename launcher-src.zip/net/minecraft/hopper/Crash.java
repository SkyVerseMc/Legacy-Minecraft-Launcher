package net.minecraft.hopper;

public class Crash {

	private int id;

	private String jira_issue;

	private String title;

	public int getId() {

		return this.id;
	}

	public String getJira_issue() {

		return this.jira_issue;
	}

	public String getTitle() {

		return this.title;
	}
}
