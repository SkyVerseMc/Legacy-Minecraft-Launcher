package net.minecraft.hopper;

public class Response {

	private String error;

	public String getError() {

		return this.error;
	}
}
