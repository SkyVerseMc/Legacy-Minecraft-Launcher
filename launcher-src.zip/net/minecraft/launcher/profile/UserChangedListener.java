package net.minecraft.launcher.profile;

public interface UserChangedListener {
	
	void onUserChanged(ProfileManager paramProfileManager);
}
