package net.minecraft.launcher.profile;

public interface RefreshedProfilesListener {

	void onProfilesRefreshed(ProfileManager paramProfileManager);
}
