package net.minecraft.launcher.updater;

public enum DownloadType {

	CLIENT,
	SERVER,
	WINDOWS_SERVER,
	CLIENT_MAPPINGS,
	SERVER_MAPPINGS;
}
