package net.minecraft.launcher.updater;

public enum ArgumentType {

	JVM, GAME;
}
