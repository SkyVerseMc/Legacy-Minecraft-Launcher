package com.mojang.launcher.game.process;

public interface GameProcessRunnable {

	void onGameProcessEnded(GameProcess paramGameProcess);
}
