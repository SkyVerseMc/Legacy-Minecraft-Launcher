package com.mojang.launcher;

public class SharedLauncherConstants {

	public static final int VERSION_FORMAT = 14;

	public static final String DEFAULT_VERSION_INCOMPATIBILITY_REASON = "This version is incompatible with your computer. Please try another one by going into Edit Profile and selecting one through the dropdown. Sorry!";
}
