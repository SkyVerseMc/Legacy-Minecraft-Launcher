package com.mojang.authlib;

public abstract class BaseAuthenticationService implements AuthenticationService {}
